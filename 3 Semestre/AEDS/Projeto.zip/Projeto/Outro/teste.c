#include <stdio.h>

double PontoMedio(int vet[], int *inicio,int fim) {
    int final = *inicio;
    double pontom;

    if(final == fim-1){
        return fim-1;
    }

    if (vet[final] != vet[final + 1] && final == 0) {
        *inicio = *inicio+1;
        return 0;
    }

    if (vet[final] != vet[final + 1]) {
        *inicio = final + 1;
        pontom = *inicio;
        return pontom;
    }

    while (vet[final] == vet[final + 1]) {
        final++;
    }

    pontom = (final + *inicio) / 2;
    *inicio = final;
    return pontom;
}

int main() {
    int n, inicio = 0; // Corrigido para um int simples, não um ponteiro
    scanf("%i", &n);
    int vet[n];
    

    for (int i = 0; i < n; i++) {
        scanf("%i", &vet[i]);
    }

    int pontoMedio = PontoMedio(vet, &inicio,n);
    printf("\nPonto médio: %d", pontoMedio);
    printf("\n");
    pontoMedio = PontoMedio(vet, &inicio,n);
    printf("\nPonto médio: %d", pontoMedio);
    pontoMedio = PontoMedio(vet, &inicio,n);
    printf("\nPonto médio: %d", pontoMedio);
    
    return 0;
}
