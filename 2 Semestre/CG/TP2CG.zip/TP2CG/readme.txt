Trabalho Prático 2

// Nomes dos integrantes do grupo e seus números de matrícula:

Alexander Neves 
20223008660

Arthur Henrique
20223009210

Davi Paulino
20223011174

Iuri Veras
20223010426

Maurilio Novaes
20223007968

Pedro Vieira
20223009185

//Instruções para compilação e execução do projeto

Para compilação e execução do projeto no Linux, devem estar instaladas as bibliotecas necessárias. Caso não as tenha, digite os seguintes comandos no terminal:

    sudo apt update

    sudo apt install build-essential gdb

    sudo apt-get install libglfw3-dev libgl1-mesa-dev libglu1-mesa-dev freeglut3-dev libglew-dev

    sudo apt-get install libsoil-dev

Após a devida instalação acima, abra o terminal na pasta raiz do jogo e digite:
Para compilar e executar o jogo:
    make executar

Para apenas compilar o jogo:
    make compilar

Para limpar os arquivos residuais de compilação:
    make limpar

//Instruções para jogar

As teclas W, A S e D movimentam a câmera. 
A barra de espaço sobe a câmera.
O botão z abaixa a câmera.
As teclas 1, 2, 3 e 4 acendem e apagam as luzes de cada cômodo.
A tecla 5 apaga e acende a iluminação global.
As teclas + e - alteram a intensidade desses componentes da luz global.
As teclas O e P, respectivamente, aumentam e diminuem a névoa.
O mouse move a câmera em volta de sua posição.
O botão ESC encerra o jogo.

//Link para gameplay
https://youtu.be/Wg5caoL9G5s
