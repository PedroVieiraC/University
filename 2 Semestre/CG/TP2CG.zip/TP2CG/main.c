#include <GL/glew.h>
#include <GL/freeglut.h>
#include "SOIL/SOIL.h"
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>

// gcc SOIL//*.c main.c -lopengl32 -lglu32 -lfreeglut -lglew32

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct{
    double x, y, z,
    xCursor, yCursor, zCursor,
    raio, teta, phi;
}Camera;

typedef struct{
    float ambiente[4];
    float difusa[4];
    float especular[4];
    float brilhosidade;
}Material;

//Struct para as luzes do tipo holofote
typedef struct{
    float posicao[4];
    float ambiente[4];
    float difusa[4];
    float especular[4];
    int direcao[4];
    float cutoff;
    int acesa;
}Luz;

typedef struct{
    float luz[4];
    float posicao[4];
    int direcao[3];
    int acesa;
}LuzAmbiente;

typedef struct{
    double x, y;
}Vetor2d;

typedef struct{
    double x, y, z;
}Vetor3d;

typedef struct{
    Vetor3d posicao;
    Vetor2d textura;
    Vetor3d normal;
}Vertice;

typedef struct{
    Vertice* vertices;
    int quantidade_vertices;
}Face;

Camera camera = {0, 0, 10, 10, 50, 10, 1, 0, M_PI/2};

Material obsidian = {{0.05375, 0.05, 0.06625}, {0.18275, 0.17, 0.22525}, {0.332741, 0.328634, 0.346435}, 38.4};
Material silver	= {{0.19225, 0.19225, 0.19225}, {0.50754, 0.50754, 0.50754}, {0.508273, 0.508273, 0.508273}, 51.2};

Material materialTerreno = {{0.1, 0.4, 0.1, 0.2}, {0.07, 0.5, 0.11, 1.0}, {0.2, 0.2, 0.2, 1.0}, 8.0};
Material madeira = {{0.27969, 0.14375, 0.00250, 1.0}, {0.4375, 0.21875, 0.00391, 1.0}, {0.9975, 0.68875, 0.12391, 1.0}, 8};
Material madeiraDentroCasa = {{0.2, 0.2, 0, 0.5}, {0.5882, 0.2941, 0, 0.5}, {0.3, 0.01, 0.01}, 8};
Material madeiraForaCasa = {{0.2, 0.2, 0, 0.5}, {0.5450, 0, 0, 1.0}, {0, 0, 0}, 8};
Material estofadoAzul = {{0.02, 0.02, 0.1, 0.5}, {0.2, 0.2, 0.6, 1.0}, {0.1, 0.3, 0.1, 1}, 8};
Material estofadoVermelho = {{0.1745, 0.01175, 0.01175}, {0.61424, 0.04136, 0.64136}, {0.42, 0.13, 0.13, 1}, 8};
Material estofadoVerde = {{0.0215, 0.1745, 0.0215}, {0.075, 0.61, 0.075}, {0.3, 0.32, 0.3, 1}, 8};
Material materialFolhas = {{0.1, 0.4, 0.1, 0.2}, {0, 0.5, 0.1, 1.0}, {0.01, 0.2, 0.01, 1.0}, 8.0};

Luz luzes[4];

Luz luz1 = {
    {390, 70, -50, 1}, {0.25, 0.25, 0.25, 1.0}, {1.0, 1.0, 1.0, 1.0}, 
    {1.0, 1.0, 1.0, 1.0}, {0, -1, 0}, 70, 0
};

Luz luz2 = {
    {390, 70, -250, 1}, {0.30, 0.30, 0.30, 1.0}, {0.2, 1.0, 0.2, 1.0}, 
    {0.4, 1.0, 0.4, 1.0}, {0, -1, 0}, 70, 0
};

Luz luz3 = {
    {200, 70, -250, 1}, {0.12, 0.12, 0.12, 1.0}, {1.0, 0.1, 0.1, 1.0}, 
    {1.0, 0.1, 0.1, 1.0}, {0, -1, 0}, 90, 0
};

Luz luz4 = {
    {40, 70, -250, 1}, {0.20, 0.20, 0.20, 1.0}, {0.2, 0.2, 1.0, 1.0}, 
    {0.4, 4.0, 1.0, 1.0}, {0, -1, 0}, 70, 0
};

LuzAmbiente luzAmbiente = {{1.0, 1.0, 1.0, 1.0}, {0, 300, 0, 1}, {0, -1, 0}, 1};

typedef struct{
    char arquivo[40];
    Face* faces;
    char *arrayzao;
    int quantidade_faces;
}Modelo;

Modelo casa = {"modelos/casa.obj", NULL, NULL, 0};
Modelo geladeira = {"modelos/geladeira.obj", NULL, NULL, 0};
Modelo mesa = {"modelos/mesa.obj", NULL, NULL, 0};
Modelo cadeira = {"modelos/cadeira.obj", NULL, NULL, 0};
Modelo asasMoinho = {"modelos/asasMoinho.obj", NULL, NULL, 0};
Modelo baseMoinho = {"modelos/baseMoinho.obj", NULL, NULL, 0};
Modelo mesaRedonda = {"modelos/mesaRedonda.obj", NULL, NULL, 0};
Modelo sofa = {"modelos/sofa.obj", NULL, NULL, 0};
Modelo camaBase = {"modelos/camaBase.obj", NULL, NULL, 0};
Modelo camaColchao = {"modelos/camaColchao.obj", NULL, NULL, 0};
Modelo camaTravesseiro = {"modelos/camaTravesseiro.obj", NULL, NULL, 0};
Modelo arvoreCaule = {"modelos/arvoreCaule.obj", NULL, NULL, 0};
Modelo arvoreFolhas = {"modelos/arvoreFolhas.obj", NULL, NULL, 0};
Modelo banco = {"modelos/banco.obj", NULL, NULL, 0};
Modelo bancoVazado = {"modelos/bancoVazado.obj", NULL, NULL, 0};

Modelo* modelos[15];

int quantidade_modelos = 15;

GLuint texturaMadeira, texturaMetalClaro,
texturaMetalEscuro, texturaGrama, texturaFolhas, texturaTronco, texturaEstofado;

float corNeblina[] = {0.6, 0.6, 0.6};
float densidadeNeblina = 0.005;

double anguloMoinho = 0;
double incrementoMoinho = 1;

GLuint carregaTextura(char* arquivo){
    GLuint idTextura = SOIL_load_OGL_texture(
        arquivo,
        SOIL_LOAD_AUTO,
        SOIL_CREATE_NEW_ID,
        SOIL_FLAG_INVERT_Y
    );

    if (idTextura == 0) {
        printf("Erro carregando a textura: '%s'\n", SOIL_last_result());
    }

    return idTextura;
}

char* inicializaVertexArrayTriangulos(int quantosTris, Face *faces) {
    // coords, textura, normal
    int quantosFloatsPorVertice = 3 + 2 + 3;
    char *arrayzao = (char*) malloc(
        quantosTris * 3 *
        quantosFloatsPorVertice *
        sizeof(GLdouble)
    );
    GLdouble* p = (GLdouble*) arrayzao;

    // para cada triângulo, colocar dados de seus vértices
    for (int i = 0; i < quantosTris; i++, p += quantosFloatsPorVertice * 3) {
        Face* f = &faces[i];

        // vértice 0
        memcpy(&p[0], &(f->vertices[0]), sizeof(GLdouble) * 8);

        // vértice 1
        memcpy(&p[8], &(f->vertices[1]), sizeof(GLdouble) * 8);

        // vértice 2
        memcpy(&p[16], &(f->vertices[2]), sizeof(GLdouble) * 8);
    }

  return arrayzao;
}

void loadOBJ(Modelo *modelo){
    FILE *arquivo;
    arquivo = fopen(modelo->arquivo, "r");

    if(arquivo == NULL){
        printf("Não foi possível abrir o arquivo");
        return;
    }

    char* linha = (char*) malloc(100*sizeof(char));
    double v1, v2, v3;

    Face* faces = NULL;
    int quantidade_faces = 0;

    Vetor3d* posicao_vertices = NULL;
    int quantidade_posicao_vertices = 0;

    Vetor3d* normal_vertices = NULL;
    int quantidade_normal_vertices = 0;

    Vetor2d* textura_vertices = NULL;
    int quantidade_textura_vertices = 0;

    while(fgets(linha, 100, arquivo) != NULL){
        if(linha[0] == 'v'){
            if(linha[1] == 'n'){
                normal_vertices  = (Vetor3d *) realloc(
                    normal_vertices, 
                    (quantidade_normal_vertices + 1) * sizeof(Vetor3d)
                );

                sscanf(linha, "vn %lf %lf %lf", &v1, &v2, &v3);

                normal_vertices[quantidade_normal_vertices].x = v1;
                normal_vertices[quantidade_normal_vertices].y = v2;
                normal_vertices[quantidade_normal_vertices].z = v3;

                quantidade_normal_vertices++;
            }
            else if(linha[1] == 't'){
                textura_vertices  = (Vetor2d *) realloc(
                    textura_vertices, 
                    (quantidade_textura_vertices + 1) * sizeof(Vetor2d)
                );

                sscanf(linha, "vt %lf %lf", &v1, &v2);

                textura_vertices[quantidade_textura_vertices].x = v1*8;
                textura_vertices[quantidade_textura_vertices].y = v2*8;

                quantidade_textura_vertices++;
            }else{  
                posicao_vertices  = (Vetor3d *) realloc(
                    posicao_vertices, 
                    (quantidade_posicao_vertices + 1) * sizeof(Vetor3d)
                );

                sscanf(linha, "v %lf %lf %lf", &v1, &v2, &v3);

                posicao_vertices[quantidade_posicao_vertices].x = v1;
                posicao_vertices[quantidade_posicao_vertices].y = v2;
                posicao_vertices[quantidade_posicao_vertices].z = v3;

                quantidade_posicao_vertices++;
            }
        }else if(linha[0] == 'f'){
            //Realoca a quantidade de faces
            faces = (Face*) realloc(faces, (quantidade_faces+1) * sizeof(Face));
            faces[quantidade_faces].vertices = NULL;

            Vertice * vertices = NULL;
            int qtd_vertices = 3;

            int indice_posicao1, indice_posicao2, indice_posicao3;
            int indice_normal1, indice_normal2, indice_normal3;
            int indice_textura1, indice_textura2, indice_textura3; 

            //Realoca a quantidade de vertices dessa face
            vertices = (Vertice*) realloc(
                vertices,
                qtd_vertices*sizeof(Vertice)
            );

            sscanf(linha, "f %d/%d/%d %d/%d/%d %d/%d/%d", 
                &indice_posicao1, &indice_textura1 ,&indice_normal1,
                &indice_posicao2, &indice_textura2 ,&indice_normal2,
                &indice_posicao3, &indice_textura3 ,&indice_normal3
            );
            vertices[0].textura = textura_vertices[indice_textura1-1];
            vertices[1].textura = textura_vertices[indice_textura2-1];
            vertices[2].textura = textura_vertices[indice_textura3-1];

            vertices[0].posicao = posicao_vertices[indice_posicao1-1];
            vertices[1].posicao = posicao_vertices[indice_posicao2-1];
            vertices[2].posicao = posicao_vertices[indice_posicao3-1];

            vertices[0].normal = normal_vertices[indice_normal1-1];
            vertices[1].normal = normal_vertices[indice_normal2-1];
            vertices[2].normal = normal_vertices[indice_normal3-1];

            faces[quantidade_faces].vertices = vertices;
            faces[quantidade_faces].quantidade_vertices = qtd_vertices;

            quantidade_faces++;
        }
    }

    modelo->faces = faces;
    modelo->quantidade_faces = quantidade_faces;

    fclose(arquivo);
    free(posicao_vertices);
    free(linha);
}

void inicializarModelos(){
    modelos[0] = &casa;
    modelos[1] = &geladeira;
    modelos[2] = &mesa;
    modelos[3] = &cadeira;
    modelos[4] = &asasMoinho;
    modelos[5] = &baseMoinho;
    modelos[6] = &mesaRedonda;
    modelos[7] = &sofa;
    modelos[8] = &camaBase;
    modelos[9] = &camaColchao;
    modelos[10] = &camaTravesseiro;
    modelos[11] = &arvoreCaule;
    modelos[12] = &arvoreFolhas;
    modelos[13] = &banco;
    modelos[14] = &bancoVazado;

    for(int i = 0; i < quantidade_modelos; i++){
        loadOBJ(modelos[i]);
        modelos[i]->arrayzao = inicializaVertexArrayTriangulos(modelos[i]->quantidade_faces, modelos[i]->faces);
        free(modelos[i]->faces);
    }
}

void inicializa(){
    glutSetCursor(GLUT_CURSOR_NONE);
    glEnable(GL_DEPTH_TEST); 

    glEnable(GL_LIGHT0);

    glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 1.0);

    glClearColor(corNeblina[0], corNeblina[1], corNeblina[2], 1.0f);

    luzes[0] = luz1;
    luzes[1] = luz2;
    luzes[2] = luz3;
    luzes[3] = luz4;

    inicializarModelos();

    texturaGrama = carregaTextura("imagens/grama.png");
    texturaMadeira = carregaTextura("imagens/madeira.png");
    texturaMetalClaro = carregaTextura("imagens/metalClaro.png");
    texturaMetalEscuro = carregaTextura("imagens/metalEscuro.png");
    texturaFolhas = carregaTextura("imagens/folhas.png");
    texturaTronco = carregaTextura("imagens/tronco.png");
    texturaEstofado = carregaTextura("imagens/estofado.png");
}

void desenhaComVertexArrays(char *arrayzao, int quantos) {
    const GLdouble *p = (const GLdouble*) arrayzao;
    int stride = sizeof(GLdouble)*(3+2+3);

    glVertexPointer(3, GL_DOUBLE, stride, p+0);
    glTexCoordPointer(2, GL_DOUBLE, stride, p+3);
    glNormalPointer(GL_DOUBLE, stride, p+5);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glEnableClientState(GL_NORMAL_ARRAY);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glDrawArrays(GL_TRIANGLES, 0, quantos*3);

    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
}

void desenharTerreno(){
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, materialTerreno.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, materialTerreno.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, materialTerreno.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, materialTerreno.brilhosidade);

    // Vertice por Vertice
    glPushMatrix();
        glTranslatef(0, 0, 0);
        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, texturaGrama);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        for(int i = -800; i < 800; i += 16){
            glBegin(GL_TRIANGLE_STRIP); 
                glNormal3f(0, 1, 0);
                for(int j = -800; j < 800; j += 16){

                    double tx = (j+800)/1600.0 *4;
                    double ty1 = (i+800)/1600.0 *4;
                    double ty2 = ((i-16)+800)/1600.0 *4;

                    glTexCoord2f(tx, ty1);  glVertex3f(j, -1, i);
                    glTexCoord2f(tx, ty2);  glVertex3f(j, -1, i-16);
                }
            glEnd();
        }
        glDisable(GL_TEXTURE_2D);
    glPopMatrix();
}

void desenharCubosIluminacao(){
    for(int i = 0; i < 4; i++){
        glPushMatrix();
        glTranslatef(luzes[i].posicao[0], luzes[i].posicao[1], luzes[i].posicao[2]);
            glutSolidCube(5);
        glPopMatrix();
    }

    glPushMatrix();
    glTranslatef(luzAmbiente.posicao[0], luzAmbiente.posicao[1], luzAmbiente.posicao[2]);
        glutSolidCube(5);
    glPopMatrix();
}

void configurarLuzes(){
    glLightfv(GL_LIGHT0, GL_POSITION, luzAmbiente.posicao);
    glLightfv(GL_LIGHT0, GL_AMBIENT, luzAmbiente.luz);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, luzAmbiente.luz);
    glLightfv(GL_LIGHT0, GL_SPECULAR, luzAmbiente.luz);
    glLightiv(GL_LIGHT0, GL_SPOT_DIRECTION, luzAmbiente.direcao);

    glLightfv(GL_LIGHT1, GL_POSITION, luzes[0].posicao);
    glLightfv(GL_LIGHT1, GL_AMBIENT, luzes[0].ambiente);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, luzes[0].difusa);
    glLightfv(GL_LIGHT1, GL_SPECULAR, luzes[0].especular);
    glLightiv(GL_LIGHT1, GL_SPOT_DIRECTION, luzes[0].direcao);
    glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, luzes[0].cutoff);

    glLightfv(GL_LIGHT2, GL_POSITION, luzes[1].posicao);
    glLightfv(GL_LIGHT2, GL_AMBIENT, luzes[1].ambiente);
    glLightfv(GL_LIGHT2, GL_DIFFUSE, luzes[1].difusa);
    glLightfv(GL_LIGHT2, GL_SPECULAR, luzes[1].especular);
    glLightiv(GL_LIGHT2, GL_SPOT_DIRECTION, luzes[1].direcao);
    glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, luzes[1].cutoff);

    glLightfv(GL_LIGHT3, GL_POSITION, luzes[2].posicao);
    glLightfv(GL_LIGHT3, GL_AMBIENT, luzes[2].ambiente);
    glLightfv(GL_LIGHT3, GL_DIFFUSE, luzes[2].difusa);
    glLightfv(GL_LIGHT3, GL_SPECULAR, luzes[2].especular);
    glLightiv(GL_LIGHT3, GL_SPOT_DIRECTION, luzes[2].direcao);
    glLightf(GL_LIGHT3, GL_SPOT_CUTOFF, luzes[2].cutoff);

    glLightfv(GL_LIGHT4, GL_POSITION, luzes[3].posicao);
    glLightfv(GL_LIGHT4, GL_AMBIENT, luzes[3].ambiente);
    glLightfv(GL_LIGHT4, GL_DIFFUSE, luzes[3].difusa);
    glLightfv(GL_LIGHT4, GL_SPECULAR, luzes[3].especular);
    glLightiv(GL_LIGHT4, GL_SPOT_DIRECTION, luzes[3].direcao);
    glLightf(GL_LIGHT4, GL_SPOT_CUTOFF, luzes[3].cutoff);
}

void desenharCama(double x, double y, double z){
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaEstofado);
    glPushMatrix();
    glTranslatef(x, y, z);
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, silver.ambiente);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, silver.difusa);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, silver.especular);
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, silver.brilhosidade);
        desenhaComVertexArrays(camaBase.arrayzao, camaBase.quantidade_faces);

        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, estofadoVermelho.ambiente);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, estofadoVermelho.difusa);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, estofadoVermelho.especular);
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, estofadoVermelho.brilhosidade);

        desenhaComVertexArrays(camaColchao.arrayzao, camaColchao.quantidade_faces);
        
        glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, estofadoVerde.ambiente);
        glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, estofadoVerde.difusa);
        glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, estofadoVerde.especular);
        glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, estofadoVerde.brilhosidade);
        desenhaComVertexArrays(camaTravesseiro.arrayzao, camaTravesseiro.quantidade_faces);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void desenharArvore(double x, double y, double z){

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaTronco);
    glPushMatrix();
        glScalef(2.0, 2.0, 2.0);
        glTranslatef(x, y, z);
        glMaterialfv(GL_FRONT, GL_AMBIENT, madeiraForaCasa.ambiente);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, madeiraForaCasa.difusa);
        glMaterialfv(GL_FRONT, GL_SPECULAR, madeiraForaCasa.especular);
        glMaterialf(GL_FRONT, GL_SHININESS, madeiraForaCasa.brilhosidade);

        desenhaComVertexArrays(arvoreCaule.arrayzao, arvoreCaule.quantidade_faces);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, materialFolhas.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, materialFolhas.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, materialFolhas.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, materialFolhas.brilhosidade);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaFolhas);
        glPushMatrix();
            glScalef(2.0, 2.0, 2.0);
            glTranslatef(x, y, z);
            desenhaComVertexArrays(arvoreFolhas.arrayzao, arvoreFolhas.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void desenharBancos(double x, double y, double z){
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMetalEscuro);
        glPushMatrix();
            glTranslatef(x, y, z);
            desenhaComVertexArrays(banco.arrayzao, banco.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMetalEscuro);
        glPushMatrix();
            glTranslatef(x+60, y, z);
            desenhaComVertexArrays(bancoVazado.arrayzao, bancoVazado.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void desenhaCena(){
    glEnable(GL_LIGHTING);
    configurarLuzes();

    glFogi(GL_FOG_MODE, GL_EXP2);
    glFogfv(GL_FOG_COLOR, corNeblina);
    glFogf(GL_FOG_DENSITY, densidadeNeblina);
    glHint(GL_FOG_HINT, GL_DONT_CARE);
    glFogf(GL_FOG_START, 0.0f);
    glFogf(GL_FOG_END, 200.0f);
    glEnable(GL_FOG); 

    glLoadIdentity();

    double x = camera.x + camera.xCursor;
    double y = camera.yCursor - camera.y;
    double z = camera.z + camera.zCursor;

    gluLookAt(camera.xCursor, camera.yCursor, camera.zCursor, x, y, z, 0, 1, 0);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    desenharTerreno();

    glMaterialfv(GL_FRONT, GL_AMBIENT, madeiraForaCasa.ambiente);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, madeiraForaCasa.difusa);
    glMaterialfv(GL_FRONT, GL_SPECULAR, madeiraForaCasa.especular);
    glMaterialf(GL_FRONT, GL_SHININESS, madeiraForaCasa.brilhosidade);

    glMaterialfv(GL_BACK, GL_AMBIENT, madeiraDentroCasa.ambiente);
    glMaterialfv(GL_BACK, GL_DIFFUSE, madeiraDentroCasa.difusa);
    glMaterialfv(GL_BACK, GL_SPECULAR, madeiraDentroCasa.especular);
    glMaterialf(GL_BACK, GL_SHININESS, madeiraDentroCasa.brilhosidade);

    glPushMatrix();
    glTranslatef(500, 0, -200);
        desenhaComVertexArrays(casa.arrayzao, casa.quantidade_faces);
    glPopMatrix();

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, silver.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, silver.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, silver.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, silver.brilhosidade);

    glPushMatrix();
    glTranslatef(450, 0, 0);
        glRotatef(-90, 0, 1, 0);
        desenhaComVertexArrays(geladeira.arrayzao, geladeira.quantidade_faces);
    glPopMatrix();

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, madeira.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, madeira.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, madeira.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, madeira.brilhosidade);

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMadeira);
        glPushMatrix();
        glTranslatef(400, 0, -300);
            desenhaComVertexArrays(mesa.arrayzao, mesa.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, madeira.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, madeira.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, madeira.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, madeira.brilhosidade);

    //Posicionando as cadeiras
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMadeira);
        glPushMatrix();
        glTranslatef(370, 0, -340);
            desenhaComVertexArrays(cadeira.arrayzao, cadeira.quantidade_faces);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(410, 0, -340);
            desenhaComVertexArrays(cadeira.arrayzao, cadeira.quantidade_faces);
        glPopMatrix();

        glPushMatrix();
        glTranslatef(460, 0, -300);
            glRotatef(-90, 0, 1, 0);
            desenhaComVertexArrays(cadeira.arrayzao, cadeira.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, silver.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, silver.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, silver.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, silver.brilhosidade);
    
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMetalClaro);
    glPushMatrix();
        glTranslatef(-250, 0, -250);
            desenhaComVertexArrays(baseMoinho.arrayzao, baseMoinho.quantidade_faces);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, obsidian.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, obsidian.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, obsidian.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, obsidian.brilhosidade);

    glPushMatrix();
        glTranslatef(-250, 0, -250);
        glTranslatef(0, 247.168091, 51.586571);
        glRotatef(90, 1, 0, 0);
        glRotatef(anguloMoinho, 0, 1, 0);
            desenhaComVertexArrays(asasMoinho.arrayzao, asasMoinho.quantidade_faces);
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaMetalEscuro);
        glPushMatrix();
            glTranslatef(-75, 0, 150);
                desenhaComVertexArrays(mesaRedonda.arrayzao, mesaRedonda.quantidade_faces);
            glTranslatef(0, 0, 100);
                desenhaComVertexArrays(mesaRedonda.arrayzao, mesaRedonda.quantidade_faces);
        glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    desenharBancos(-280, 0, 300);
    desenharBancos(-280, 0, 200);
    desenharBancos(-280, 0, 100);
    desenharBancos(-450, 0, 300);
    desenharBancos(-450, 0, 200);
    desenharBancos(-450, 0, 100);

    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, estofadoAzul.ambiente);
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, estofadoAzul.difusa);
    glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, estofadoAzul.especular);
    glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, estofadoAzul.brilhosidade);
    
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texturaEstofado);
    glPushMatrix();
        glTranslatef(20, 0, -350);
        glScalef(2.0, 2.0, 2.0);
            desenhaComVertexArrays(sofa.arrayzao, sofa.quantidade_faces);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    desenharArvore(100, 0, 100);
    desenharArvore(150, 0, 300);
    desenharArvore(0, 0, 240);
    desenharArvore(70, 0, 150);
    desenharArvore(190, 0, 100);

    desenharCama(250, 0, -340);
    desenharCubosIluminacao();

    glDisable(GL_LIGHTING);
    glutSwapBuffers();
}

void atualiza() {
    camera.x = camera.raio * sin(camera.phi) * cos(camera.teta);  //coordenada x denotada em coordenadas esféricas
    camera.z = camera.raio * sin(camera.phi) * sin(camera.teta);  //coordenada z denotada em coordenadas esféricas
    camera.y = camera.raio * cos(camera.phi);                     //coordenada y denotada em coordenadas esféricas

    anguloMoinho += incrementoMoinho;

    glutTimerFunc(16, atualiza, 16);
    glutPostRedisplay();
}

void redimensiona(int width, int height){
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluPerspective(60.0, (float)width/(float)height, 1, 800.0);
    
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void teclaPressionada(unsigned char key, int x, int y){
    switch(key){
        case 'w':
            camera.xCursor += 5;
            break;
        case 'a':
            camera.zCursor -= 5;
            break;
        case 's':
            camera.xCursor -= 5;
            break;
        case 'd':
            camera.zCursor += 5;
            break;
        case ' ':
            camera.yCursor +=5;
            break;
         case 'z':
            camera.yCursor -=5;
            break;
        case '+':
            if(luzAmbiente.luz[0] <= 0.95){
                luzAmbiente.luz[0] +=0.05;
                luzAmbiente.luz[1] +=0.05;
                luzAmbiente.luz[2] +=0.05;
                luzAmbiente.luz[3] +=0.05;
            }else{
                luzAmbiente.luz[0] = 1;
                luzAmbiente.luz[1] = 1;
                luzAmbiente.luz[2] = 1;
                luzAmbiente.luz[3] = 1;
            }
            break;
         case '-':
            if(luzAmbiente.luz[0] >= 0.05){
                luzAmbiente.luz[0] -= 0.05;
                luzAmbiente.luz[1] -= 0.05;
                luzAmbiente.luz[2] -= 0.05;
                luzAmbiente.luz[3] -= 0.05;
            }else{
                luzAmbiente.luz[0] = 0;
                luzAmbiente.luz[1] = 0;
                luzAmbiente.luz[2] = 0;
                luzAmbiente.luz[3] = 0;
            }
            break;
        case 'o':
            if(densidadeNeblina < 1)
                densidadeNeblina += 0.001;
            break;
        case 'p':
            if(densidadeNeblina > 0)
                densidadeNeblina -= 0.001;
            break;
        case '1':
            if(luzes[0].acesa){
                glDisable(GL_LIGHT1);
                luzes[0].acesa = 0;
            }else{
                glEnable(GL_LIGHT1);
                luzes[0].acesa = 1;
            }
            break;
        case '2':
            if(luzes[1].acesa){
                glDisable(GL_LIGHT2);
                luzes[1].acesa = 0;
            }else{
                glEnable(GL_LIGHT2);
                luzes[1].acesa = 1;
            }
            break;
        case '3':
            if(luzes[2].acesa){
                glDisable(GL_LIGHT3);
                luzes[2].acesa = 0;
            }else{
                glEnable(GL_LIGHT3);
                luzes[2].acesa = 1;
            }
            break;
        case '4':
            if(luzes[3].acesa){
                glDisable(GL_LIGHT4);
                luzes[3].acesa = 0;
            }else{
                glEnable(GL_LIGHT4);
                luzes[3].acesa = 1;
            }
            break;
        case '5':
            if(luzAmbiente.acesa){
                glDisable(GL_LIGHT0);
                luzAmbiente.acesa = 0;
            }else{
                glEnable(GL_LIGHT0);
                luzAmbiente.acesa = 1;
            }
            break;
        case 27:
            exit(0);
    }
}

double xMouse = 0, yMouse = 0;
void posicionaCamera(int x, int y){
    float distX = x - xMouse;
    float distY = y - yMouse;

    camera.teta = (camera.teta + distX/50);
    camera.phi = (camera.phi - distY/50);

    if (camera.phi > M_PI) {
        camera.phi = M_PI - 0.0001f;
    }

    else if (camera.phi < 0) {
        camera.phi = 0.0001f;
    }

    xMouse = x;
    yMouse = y;
}

int main(int argc, char *argv[]){
    glutInit(&argc, argv);
    glutInitContextVersion(1, 1);
    glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition (200, 100);

    glutCreateWindow("Mini TP2 CG");

    inicializa();

    glutDisplayFunc(desenhaCena);
    glutReshapeFunc(redimensiona);

    glutKeyboardFunc(teclaPressionada);
    glutPassiveMotionFunc(posicionaCamera);

    glutTimerFunc(16, atualiza, 16);

    glutMainLoop();

    return 0;
}
