package principal_arthur_pedroVieira;

import java.util.ArrayList;

public class Turma {
    
    private ArrayList<Aluno> alunos;

    public Turma(){
        alunos = new ArrayList<Aluno>();
    }

    public ArrayList<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(ArrayList<Aluno> alunos) {
        this.alunos = alunos;
    }

    public void adicionarAluno(Aluno aluno){
        alunos.add(aluno);
    }

    public boolean procuraAluno(String mat){
        for(Aluno aluno: alunos){
            if(aluno.getMat().equals(mat)){
                return true;
            }
        }
            return false;
    }

    public Aluno fezProva(String mat){
        for(Aluno aluno : alunos){
            if(aluno.getMat().equals(mat)){
                return aluno;
            }
        }
        return null;
    }

    
}
