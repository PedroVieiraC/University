package principal_arthur_pedroVieira;

public class Aluno {

    private String mat;
    private String nome;

    public Aluno(String mat, String nome) {
        this.mat = mat;
        this.nome = nome;
    }
    
    public String getMat() {
        return mat;
    }
    public void setMat(String mat) {
        this.mat = mat;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }


    
}
