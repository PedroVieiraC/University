package principal_arthur_pedroVieira;

import java.util.HashMap;
import java.util.Set;


public class Avaliacao extends Turma {

    private HashMap <String,Integer> participantes;

    public Avaliacao() {
        participantes = new HashMap <String,Integer>();
    }
    public void adicionarAluno(Aluno aluno){
        getAlunos().add(aluno);
    }

    public HashMap<String, Integer> getParticipantes() {
        return participantes;
    }

    public void setParticipantes(HashMap<String, Integer> participantes) {
        this.participantes = participantes;
    }



    

    public void adicionarParticipante(int nota, String mat){
        for(Aluno aluno : getAlunos()){
            if(aluno.getMat().equals(mat)){
                participantes.put(mat,nota);
            }
        }
    }
    
   

    public double calculaMedia(){
        double media =0;
        Set <String> chave = participantes.keySet();
            for(String mat:chave){
                media += participantes.get(mat);
            }
            media/=participantes.size();
            return media;
            }




    
        }
    
    


