import java.util.Scanner;

import principal_arthur_pedroVieira.Aluno;
import principal_arthur_pedroVieira.Avaliacao;
import principal_arthur_pedroVieira.Turma;

public class RegistroEscolar {

    public static void main(String[] args) {

        Avaliacao provinha = new Avaliacao();

        Aluno a1 = new Aluno("11111", "Vitor Cavalcanti Ribeiro");
        Aluno a2 = new Aluno("22222", "Davi Fernandes Barros");

        Turma turma = new Turma();
        turma.adicionarAluno(a1);
        turma.adicionarAluno(a2);

        Scanner entrada = new Scanner(System.in);

        System.out.println("AVISO!!!! \nSe a matrícula digitada for -1 o programa se encerra\nDigite a matrícula: ");
        String mat = entrada.next();

    while(mat.equals("-1")==false){
        if (turma.procuraAluno(mat)) {
            provinha.adicionarAluno(turma.fezProva(mat));
            System.out.println("Digite a nota do Aluno:");
            int nota = entrada.nextInt();
            provinha.adicionarParticipante(nota, mat);
        } else {
            System.out.println("Aluno não consta no banco de dados da escola");
        }
        System.out.println("AVISO!!!! \nSe a matrícula digitada for -1 o programa se encerra\nDigite a matrícula: ");
        mat = entrada.next();
    }
        System.out.println("A média das notas é:"+provinha.calculaMedia());
    }
}
