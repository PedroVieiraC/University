package classes;

import java.util.Random;

public class Pack {
    private Card[] pack;
    private static String[] naipe = { "Ouros", "Paus", "Espadas", "Coração" };
    private static Random random = new Random();

    public Pack() {
        pack = new Card[52];
        int pos = 0;

        for (int i = 0; i < naipe.length; i++) {
            for (int j = 1; j < 14; j++) {
                pack[pos] = new Card(j, naipe[i]);
                pos++;
            }
        }
    }

    public Card[] sortDeck(int deckLength) {
        Card[] deck = new Card[deckLength];

        for (int i = 0; i < deckLength; i++) {
            deck[i] = getRandomCard();
        }

        return deck;
    }

    private Card getRandomCard() {
        Card randomCard;
        int randomPosition = random.nextInt(51);
        while (pack[randomPosition] == null) {
            randomPosition = random.nextInt(51);
        }
        randomCard = pack[randomPosition];
        pack[randomPosition] = null;

        return randomCard;

    }

    public Card[] getPack() {
        return pack;
    }

    public void setPack(Card[] pack) {
        this.pack = pack;
    }

    public static String[] getNaipe() {
        return naipe;
    }

    public static void setNaipe(String[] naipe) {
        Pack.naipe = naipe;
    }

}
