package classes;

public class Player {

    private int deckLength;
    private Card[] deck;

    public Player(int deckLength, Pack pack) {
        this.deckLength = deckLength;
        this.deck = pack.sortDeck(deckLength);
    }

    public Card getBiggerCard() {

        Card biggerCard = deck[0];
        for (int i = 0; i < deck.length; i++) {
            if (biggerCard.compareValue(deck[i]) == -1) {
                biggerCard = deck[i];
            }
        }

        return biggerCard;
    }

    public int getDeckLength() {
        return deckLength;
    }

    public void setDeckLength(int deckLength) {
        this.deckLength = deckLength;
    }

    public Card[] getDeck() {
        return deck;
    }

    public void setDeck(Card[] deck) {
        this.deck = deck;
    }

}
