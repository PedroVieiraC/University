package classes;

public class Card {

    private String suit;
    private int value;

    public Card(int value, String suit) {
        this.suit = suit;
        this.value = value;
    }

    public int compareValue(Card card) {

        if (card.getValue() < this.value) {
            return 1;
        }
        if (card.getValue() > this.value) {
            return -1;
        }

        return 0;

    }

    public boolean compareSuit(Card card) {

        if (card.getSuit().equals(this.suit)) {
            return true;
        }

        return false;
    }

    public String getSuit() {
        return this.suit;
    }

    public void setSuit(String suit) {
        this.suit = suit;
    }

    public int getValue() {
        return this.value;
    }

    public void setValue(int value) {
        this.value = value;
    }

}
