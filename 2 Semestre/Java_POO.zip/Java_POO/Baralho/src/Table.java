import java.util.Scanner;

import classes.Pack;
import classes.Player;

public class Table {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);
        System.out.print("Digite o tamanho do baralho: ");
        int deckLength = input.nextInt();

        Pack baralho = new Pack();
        Player player1 = new Player(deckLength, baralho);
        Player player2 = new Player(deckLength, baralho);

        System.out.println("Player1 " + player1.getBiggerCard().getValue());
        System.out.println("Player1 Naipe " + player1.getBiggerCard().getSuit());

        System.out.println("Player2 " + player2.getBiggerCard().getValue());
        System.out.println("Player2 Naipe " + player2.getBiggerCard().getSuit());

        if (player1.getBiggerCard().compareValue(player2.getBiggerCard()) == 1) {
            System.out.println("Player1 Venceu!");
        } else if (player1.getBiggerCard().compareValue(player2.getBiggerCard()) == -1) {
            System.out.println("Player2 Venceu!");
        } else {
            if (player1.getBiggerCard().getSuit() == "Ouros" && player2.getBiggerCard().getSuit() != "Ouros") {
                System.out.println("Player1 Venceu!");
            } else if (player2.getBiggerCard().getSuit() == "Ouros" && player1.getBiggerCard().getSuit() != "Ouros") {
                System.out.println("Player2 Venceu!");
            } else {
                Table.main(args);
            }
        }
    }
}
