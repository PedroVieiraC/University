/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package prova_pedro_arthur_controle;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import prova_pedro_arthur_logica.*;

/**
 *
 * @author Marcela
 */
public class FXMLDocumentController implements Initializable {
    
    private Logica logica = new Logica();
    
     @FXML
    private Button bt_remover;

    @FXML
    private RadioButton bt_08;

    @FXML
    private RadioButton bt_17;

    @FXML
    private TextField txt_duracao;

    @FXML
    private RadioButton bt_16;

    @FXML
    private RadioButton bt_15;

    @FXML
    private Label label;

    @FXML
    private RadioButton bt_14;

    @FXML
    private Button bt_Consultar;

    @FXML
    private RadioButton bt_09;

    @FXML
    private Button bt_limpar;

    @FXML
    private Button bt_alterar;

    @FXML
    private RadioButton bt_13;

    @FXML
    private RadioButton bt_12;

    @FXML
    private RadioButton bt_11;

    @FXML
    private RadioButton bt_10;

    @FXML
    private ComboBox<String> bt_dias = new ComboBox<>();

    @FXML
    private Button bt_incluir;

    @FXML
    private TextField txt_nome;

    
    private ToggleGroup grupoBotoes;        
      
    @FXML        
    void limpar(ActionEvent event) {

        this.txt_nome.setDisable(false);
        this.txt_duracao.setDisable(false);
        
        this.txt_nome.setText("");
        this.txt_duracao.setText("");
        
        this.bt_dias.setValue(null);
        
    }
    
     void limpara() {

        this.txt_nome.setDisable(false);
        this.txt_duracao.setDisable(false);
        
        this.txt_nome.setText("");
        this.txt_duracao.setText("");
        
        this.bt_dias.setValue(null);
        
    }

    

    void preencheToggleGroup(){
     grupoBotoes = new ToggleGroup();
     bt_08.setToggleGroup(grupoBotoes);
     bt_09.setToggleGroup(grupoBotoes);
     bt_10.setToggleGroup(grupoBotoes);
     bt_11.setToggleGroup(grupoBotoes);
     bt_12.setToggleGroup(grupoBotoes);
     bt_13.setToggleGroup(grupoBotoes);
     bt_14.setToggleGroup(grupoBotoes);
     bt_15.setToggleGroup(grupoBotoes);
     bt_16.setToggleGroup(grupoBotoes);
     bt_17.setToggleGroup(grupoBotoes);
     bt_08.setSelected(true);
   
    }
    
    @FXML
    void consulta(ActionEvent event) {
    int hr=Integer.parseInt(((RadioButton)grupoBotoes.getSelectedToggle()).getText());
    System.out.println(logica.ConsultaPaciente(bt_dias.getValue(), hr));    
    //txt_nome.setText();
        
    }
    
    @FXML
    void incluir(ActionEvent event)  {
        
    int hr=Integer.parseInt(((RadioButton)grupoBotoes.getSelectedToggle()).getText());
    
        try{
        logica.preencherHorarios(bt_dias.getValue(), hr,Integer.parseInt(txt_duracao.getText()),txt_nome.getText());
        }catch(DuplicidadeException e){
        System.out.println("horario cheio");
        }
    limpara();
    }

    @FXML
    void remover(ActionEvent event) {
    int hr=Integer.parseInt(((RadioButton)grupoBotoes.getSelectedToggle()).getText());
        logica.removePaciente(bt_dias.getValue(), hr,Integer.parseInt(txt_duracao.getText()),txt_nome.getText());
    }

    @FXML
    void alterar(ActionEvent event) {

    }

    @FXML
    void selecionarhorario(ActionEvent event) {

    }

    @FXML
    void selecionardia(ActionEvent event) {
    
    }
    
    private void preencheCombo(){
    
    bt_dias.getItems().addAll("Segunda-feira", "Terca-feira","Quarta-feira","Quinta-feira","Sexta-feira");
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        preencheCombo();
        preencheToggleGroup();
        
    }    
    
}
