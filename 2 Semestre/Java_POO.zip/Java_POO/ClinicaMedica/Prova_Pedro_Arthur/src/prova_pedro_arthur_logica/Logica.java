/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova_pedro_arthur_logica;

/**
 *
 * @author Marcela
 */
public class Logica {

    private int[][] matrizH = new int[5][10];
    private String[][] matrizN = new String[5][10];

    public void preencherHorarios(String semana, int inicio, int duracao, String nomePaciente) throws DuplicidadeException {
        int i = 0;
        semana = semana.toLowerCase();
        if (semana.equals("segunda-feira")) {
            i = 0;
        }
        if (semana.equals("terca-feira")) {
            i = 1;
        }
        if (semana.equals("quarta-feira")) {
            i = 2;
        }
        if (semana.equals("quinta-feira")) {
            i = 3;
        }
        if (semana.equals("sexta-feira")) {
            i = 4;
        }

        for (int j = inicio; j < duracao; j++) {
            matrizH[i][j] = 1;
            matrizN[i][j] = nomePaciente;
        }

        for (int j = inicio; j < duracao; j++) {
            if (matrizH[i][j] == 1) {
                DuplicidadeException e = new DuplicidadeException();
                throw e;
            }

        }

    }

    public String ConsultaPaciente(String semana, int inicio) {
        int i = 0;
        int j=0;
        semana = semana.toLowerCase();
        if (semana.equals("segunda-feira")) {
            i = 0;
        }
        if (semana.equals("terca-feira")) {
            i = 1;
        }
        if (semana.equals("quarta-feira")) {
            i = 2;
        }
        if (semana.equals("quinta-feira")) {
            i = 3;
        }
        if (semana.equals("sexta-feira")) {
            i = 4;
        }
        j = inicio;
            if(matrizH[i][j] != 0){
            return matrizN[i][j];
           }
            return null;
    }

    public void removePaciente(String semana, int inicio, int duracao, String nomePaciente){
        int i = 0;
        semana = semana.toLowerCase();
        if (semana.equals("segunda-feira")) {
            i = 0;
        }
        if (semana.equals("terca-feira")) {
            i = 1;
        }
        if (semana.equals("quarta-feira")) {
            i = 2;
        }
        if (semana.equals("quinta-feira")) {
            i = 3;
        }
        if (semana.equals("sexta-feira")) {
            i = 4;
        }

        for (int j = inicio; j < duracao; j++) {
            matrizH[i][j] = 0;
            matrizN[i][j] = null;
        }
}

}
