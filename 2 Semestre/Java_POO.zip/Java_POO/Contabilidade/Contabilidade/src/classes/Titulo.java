package classes;

public class Titulo extends Conta {

    public Titulo(int dia, int mes, Double valor) {
        super(dia, mes, valor);   
    }


    public double getValorAPagar(int diaPagto, int mesPagto){
        if(this.mes<=mesPagto && this.dia<=diaPagto){
            return valor;
        }        
        return valor*1.10;
    }
    
}
