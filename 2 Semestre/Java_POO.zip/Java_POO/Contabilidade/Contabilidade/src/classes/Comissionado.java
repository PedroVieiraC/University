package classes;

public class Comissionado extends Empregado {
    protected double valorVendas;

    public double getValorVendas() {
        return valorVendas;
    }

    public void setValorVendas(double valorVendas) {
        this.valorVendas = valorVendas;
    }

    public Comissionado(String nome, String sobrenome, int numIdent, double valorVendas) {
        super(nome, sobrenome, numIdent);
        this.valorVendas = valorVendas;
    }

    public double getValorAPagar(int diaPagto, int mesPagto) {
            return (valorVendas * 0.06);
    }

}
