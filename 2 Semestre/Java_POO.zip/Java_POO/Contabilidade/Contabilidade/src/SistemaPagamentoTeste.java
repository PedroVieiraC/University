import classes.Assalariado;
import classes.AssalariadoComi;
import classes.Comissionado;
import classes.ControlePagamento;

public class SistemaPagamentoTeste {
    public static void main(String[] args) throws Exception {
        ControlePagamento debitos = new ControlePagamento();
        Assalariado joao = new Assalariado("joca","carro" ,2612, 5);
        Comissionado henr = new Comissionado("carlin","sem" , 1532, 250000);
       // AssalariadoComi ger= new AssalariadoComi(null, null, 0, 0, 0)

        debitos.addPagamentos(joao);
        debitos.addPagamentos(henr);

        System.out.println(debitos.custoTotal(0, 0));


    }
}
