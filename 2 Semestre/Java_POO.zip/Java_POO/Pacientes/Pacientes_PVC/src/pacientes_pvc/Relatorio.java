/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pacientes_pvc;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Relatorio extends Application {
       protected static Stage janela;
    public void start(Stage stage) {

        FXMLLoader fxmlLoader = new FXMLLoader(Relatorio.class.getResource("Relatorio.fxml"));
       
        Relatorio.janela =stage;
        stage.setTitle("Relatório");
        //stage.setScene(scene);
        stage.show();
    }
    
    
}
