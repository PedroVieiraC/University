/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package pacientes_pvc;

import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JButton;
import pacientes_pvc.Pessoa_PVC;
import pacientes_pvc.TreatDatas_PVC;


public class FXMLDocumentController implements Initializable {
    
     @FXML
    private Button button;
     
         Relatorio relatorioTexto = new Relatorio();

    @FXML
    private TextField txt_peso;

    @FXML
    private TextField txt_codigo;

    @FXML
    private TextField txt_altura;

    @FXML
    private ComboBox<String> txt_genero =  new ComboBox<>();;

    @FXML
    private TextField txt_nome;

    @FXML
    private TextField txt_idade;
    
    private ArrayList<Pessoa_PVC> pessoas = new ArrayList<>();    
    private Pessoa_PVC pessoa ;
    private TreatDatas_PVC datas;
          
    @FXML
    private void handleButtonAction(ActionEvent event) {
            
        String face = ((Button)event.getSource()).getText();
            
            if(face.equals("Novo")){
             pessoa = new Pessoa_PVC(txt_codigo.getText(),txt_nome.getText(),Float.parseFloat(txt_peso.getText()), txt_genero.getValue(), Integer.parseInt(txt_idade.getText()),Float.parseFloat( txt_altura.getText()));
             pessoas.add(pessoa);
             limpaTela();
            }
            
            if(face.equals("Relatorio")){
            geraJanelaRelatorio();
               
            datas = new TreatDatas_PVC(pessoas);
            System.out.println("Quantidade de pacientes: " + datas.qtdPacientes());
            System.out.println("Média de idade entre os homens: " + datas.miHomens());
            System.out.println("Mulheres entre 1,60 e 1,70 acima 70kg: " + datas.mulheresParametros());
            System.out.println("Pessoas entre 18 e 25 anos: " + datas.pessoasAcima25());
            System.out.println("Nome pessoa mais velha: " + datas.nomeMaisVelho());
            System.out.println("Nome mulher mais baixa: " + datas.nomeMaisBaixa());
            }
            
            if(((Button)event.getSource()).getText().equals("Sair")){
                //Platform.exit();
                System.exit(0);
            }
           
    }
    
     private void limpaTela(){
        this.txt_nome.setDisable(false);
        this.txt_peso.setDisable(false);
        this.txt_idade.setDisable(false);
        this.txt_altura.setDisable(false);
            //this.txt_genero.setDisable(false);
        this.txt_codigo.setDisable(false);
        
        this.txt_nome.setText("");
        this.txt_peso.setText("");
        this.txt_idade.setText("");
        this.txt_altura.setText("");
        this.txt_codigo.setText("");
        
        this.txt_genero.setValue(null);

    }

     
    private void geraJanelaRelatorio(){
        Relatorio janela = new Relatorio();
        janela.start(new Stage());
    }
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
            
        preencheCombo();
        
// TODO
    }    
private void preencheCombo(){
    //txt_genero.setItems(FXCollections.observableArrayList("Masculino", "Feminino"));
    txt_genero.getItems().addAll("masculino", "feminino");
    }
    
    
}
