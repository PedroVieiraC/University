package PC2.Espaco.classes;

import java.util.ArrayList;

public class Espaco {
    private ArrayList<Forma> formas = new ArrayList<Forma>();
    private Forma forma;
    String tipo;

    public void criaForma(Ponto[] pontos) {
        forma = Forma.geraForma(pontos);
        this.formas.add(forma);
    }

    public double calculaAreaTotal() {
        double areaT = 0;
        for (int i = 0; i < formas.size(); i++) {
            
            if (formas.get(i) != null) {
                areaT += formas.get(i).calculaArea();
            }
        }
        return areaT;

    }

    public double calculaPerimetroTotal() {
        double periT = 0;
        for (int i = 0; i < formas.size(); i++) {
            if (formas.get(i) != null) {
                periT += formas.get(i).calculaPerimetro();
            }
        }
        return periT;
    }

    public String mostraTriangulo() {
        for (Forma forma : formas) {
            if (forma instanceof Triangulo) {
                System.out.println("tipo: " + ((Triangulo) forma).tipoTriangulo());
            }

        }
        return "não é um triangulo";
    }

}
