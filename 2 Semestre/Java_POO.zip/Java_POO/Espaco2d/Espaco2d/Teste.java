package PC2.Espaco;
import java.util.Scanner;

import PC2.Espaco.classes.Espaco;
import PC2.Espaco.classes.Ponto;

public class Teste {
    public static void main(String args[]){
        Scanner entrada = new Scanner(System.in);
        System.out.println("Digite a qtd de pontos");
        int qtdP = entrada.nextInt();

        Ponto[] pontos = new Ponto[qtdP];

        for(int i=0;i<qtdP;i++){
            System.out.println("Digite o valor de x do ponto " + (i+1));
            double px = entrada.nextDouble();
            System.out.println("Digite o valor de y do ponto " + (i+1));
            double py = entrada.nextDouble();
            pontos[i]= new Ponto(px,py);
           
        }
        Espaco espaco = new Espaco();
        espaco.criaForma(pontos);

        System.out.println("\n" + "area " + espaco.calculaAreaTotal());
        System.out.println("perimetro " + espaco.calculaPerimetroTotal());
        
        entrada.close();
    }
}
