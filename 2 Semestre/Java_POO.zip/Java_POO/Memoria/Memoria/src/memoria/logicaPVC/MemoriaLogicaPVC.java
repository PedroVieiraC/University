/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memoria.logicaPVC;

import java.util.Random;

/**
 *
 * @author Marcela
 */
public class MemoriaLogicaPVC {

    public void preencheVetorAleatorio(int[] vetor) {

        Random random = new Random();
        for (int i = 0; i < vetor.length / 2; i++) {
            int j = random.nextInt(vetor.length);

            // Trocar os elementos nas posições i e j
            int temp = vetor[i];
            vetor[i] = vetor[j];
            vetor[j] = temp;
        }

        for (int i = 0; i < vetor.length / 2; i++) {
            Random j = new Random();
            int numeroAleatorio = random.nextInt(60);
            vetor[i] = vetor[numeroAleatorio];
        }

    }
}
