package classes;

import java.util.HashSet;

public class Interpretadora {
    private HashSet<String> palavraChave;

    public Interpretadora(String frase) {
        this.palavraChave = new HashSet<>();
        String[] frasesep = frase.split(" ");
        for (String frasex : frasesep) {
            this.palavraChave.add(frasex);
         }
    }

    public HashSet<String> getPalavraChave() {
        return palavraChave;
    }

    public void setPalavraChave(HashSet<String> palavraChave) {
        this.palavraChave = palavraChave;
    }
    
}
