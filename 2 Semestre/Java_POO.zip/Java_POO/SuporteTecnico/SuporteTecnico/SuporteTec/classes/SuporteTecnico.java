package classes;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class SuporteTecnico {
    private HashMap<String, String> banco;
    private ArrayList<String> respostas;
    private static Random random = new Random();


    
    public HashMap<String, String> getBanco() {
        return banco;
    }

    public void setBanco(HashMap<String, String> banco) {
        this.banco = banco;
    }

    public ArrayList<String> getRespostas() {
        return respostas;
    }

    public void setRespostas(ArrayList<String> respostas) {
        this.respostas = respostas;
    }

    public SuporteTecnico(){
        this.banco = new HashMap<String, String>();
        this.respostas = new ArrayList<String>();
        preencherBanco();
        preencherRespostaPadrao();
    }

    private void preencherBanco() {
        this.banco.put("lento",
                "Penso que o problema está relacionado com o hardware. Fazer um upgrade\n do seu processador deve resolver o problema de performance. Você tem algum\n problema com o software?");
        this.banco.put("performance",
                "A performance está próxima do esperado nos testes que realizamos. Você está\n executando algum outro processo em paralelo?");
        this.banco.put("bug",
                "Bom, você sabe, todo software pode ter algum problema. Mas nossos engenheiros de software\n já estão atuando no problema para solucioná-lo. Você poderia descrever seu problema\n com mais detalhes?");
        this.banco.put("buggy",
                "Bom, você sabe, todo software pode ter algum problema. Mas nossos engenheiros de software\n já estão atuando no problema para solucioná-lo. Você poderia descrever seu problema\n com mais detalhes?");
        this.banco.put("windows",
                "Este é um problema do sistema operacional Windows. Por favor, \n entre em contato com a Microsoft. Não há nada que possamos fazer neste caso.");
        this.banco.put("macintosh",
                "Este é um problema do sistema operacional Mac. Por favor, \n entre em contato com a Apple. Não há nada que possamos fazer neste caso.");
        this.banco.put("caro",
                "O preço do nosso produto é competitivo. Você já fez uma pesquisa de mercado\n e comparou todas as características do nosso software com outras ofertas de mercado?");
        this.banco.put("instalação",
                "A instalação é simples e direta. Nós temos programas de instalação previamente configurados\n que farão todo o trabalho para você. Você já leu as instruções\n de instalação?");
        this.banco.put("memória",
                "Se você observar detalhadamente os requisitos mínimos de sistema, você verá que\n a memória requerida é 1.5 giga byte. Você deverá adquirir\n mais memória. Mais alguma coisa que deseja saber?");
        this.banco.put("linux",
                "Nós consideramos seriamente o suporte Linux. Mas existem muitos problemas.\n Muitos deles dizem respeito a versões incompatíveis. Você poderia ser\n mais preciso?");
        this.banco.put("danificaram",
                "Bom, nosso software não danificaria seu sistema. Deve ser algo específico\n no seu sistema. Diga-me sobre sua configuração.");
        this.banco.put("danificou",
                "Bom, nosso software não danificaria seu sistema. Deve ser algo específico\n no seu sistema. Diga-me sobre sua configuração.");
    }

    private void preencherRespostaPadrao() {
        this.respostas.add(new String("Isso soa estranho. Você poderia descrever o problema com mais detalhes?"));
        this.respostas.add(new String(
                "Nenhum outro cliente detalhou um problema parecido com este. \n Qual é a sua configuração de sistema?"));
        this.respostas.add(new String("Isso parece interessante. Diga-me mais a respeito..."));
        this.respostas.add(new String("Preciso de maiores informações a respeito."));
        this.respostas.add(new String("Você já verificou se existe algum conflito de DLL?"));
        this.respostas.add(new String(
                "Isso está descrito no manual. Você já deu uma lida no manual que veio junto do seu software?"));
        this.respostas.add(new String(
                "Sua descrição não foi satisfatória. Você já procurou um técnico\n que poderia detalhar melhor este problema?"));
        this.respostas.add(new String("Isso não é um problema, é apenas uma característica do software!"));
        this.respostas.add(new String("Você poderia explicar melhor?"));
    }

    private String randomResposta() {
        return respostas.get(random.nextInt(respostas.size()));
    }

    public String buscarSolucao(HashSet<String> palavras) {
        List<String> lista = new ArrayList<String>(palavras);
        for (int i = 0; i < lista.size(); i++) {
            if (banco.get(lista.get(i)) != null) {
                return banco.get(lista.get(i));
            }
        }
        return randomResposta();

    }

    // for (String palavraA : palavras) {
    // if(banco.equals(palavraA)){
    // return banco ;
    // }
    // }
    // int i = random.nextInt(12);
    // return respostas.get(i);

}
