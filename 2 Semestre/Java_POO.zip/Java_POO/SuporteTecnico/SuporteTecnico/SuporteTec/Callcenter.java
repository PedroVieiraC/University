//import java.util.HashSet;
import java.util.Scanner;

import classes.Interpretadora;
import classes.SuporteTecnico;

public class Callcenter {
    public static void main (String args[]){

        Scanner entrada = new Scanner(System.in);
        SuporteTecnico sup = new SuporteTecnico();

        String problem = entrada.nextLine();
        Interpretadora interp = new Interpretadora(problem);


        System.out.println(sup.buscarSolucao(interp.getPalavraChave()));

        entrada.close();
    }

}
