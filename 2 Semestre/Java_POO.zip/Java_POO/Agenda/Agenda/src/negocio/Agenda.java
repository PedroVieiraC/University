package negocio;

import java.util.HashMap;

import servicos.ManipulaArquivoTexto;

public class Agenda {
    private HashMap<String, Contato> contatos ;
    

    public Agenda() {
        contatos = new HashMap<String,Contato>();
    }

    public void incluirContato(Contato contato) {
        contatos.put(contato.getNome(), contato);
    }

    public boolean existeContato(String nome) {
        for (String regNome : contatos.keySet()) {
            if (regNome.equals(nome)) {
                return true;
            }
        }
        return false;
    }

    public Contato consultarContato(String nome){
        for (String regNome : contatos.keySet()) {
            if (regNome.equals(nome)) {
                return contatos.get(nome);
            }
        }
        return null;
    }

    public void removeContato(String nome){
        contatos.remove(nome);
        }
    
    public void lerAgenda(){
        ManipulaArquivoTexto arquivoTxt = new ManipulaArquivoTexto("Agenda.txt");
        arquivoTxt.abrirArquivo();
    }    
    
    public void persistirAgenda() throws ContatoInexistenteException{
        ManipulaArquivoTexto arquivoTxt = new ManipulaArquivoTexto("Agenda.txt");
        arquivoTxt.abrirArquivoParaGravacao(contatos);
    }

}

