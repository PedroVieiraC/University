package servicos;

import negocio.Contato;
import negocio.ContatoInexistenteException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Scanner;


public class ManipulaArquivoTexto {
    public String arquivo;
    public Formatter gravador;
    public Scanner leitor;

    public ManipulaArquivoTexto(String arquivo) {
        this.arquivo = arquivo;
    }

    public void abrirArquivo() {
        try {
            BufferedReader leitor = new BufferedReader(new FileReader(arquivo));
            String linha = "";
            while (true) {
                if (linha != null) {
                    System.out.println(linha);
                } else
                    break;
                linha = leitor.readLine();
            }
            leitor.close();

        } catch (IOException exception) {
            System.out.println("O arquivo não foi encontrado!");
            System.exit(1);
        } catch (Exception exception) {
            System.out.println("Ocorreu um erro!");
            System.exit(1);
        }

    }
    public void abrirArquivoParaGravacao(HashMap<String, Contato> contatos) {
        try {

            BufferedWriter buffWrite = new BufferedWriter(new FileWriter(arquivo));
            for (java.util.Map.Entry<String, Contato> pair : contatos.entrySet()) {
                buffWrite.append("Nome: " + pair.getKey() + "\n");
                buffWrite.append("Telefone: " + pair.getValue().getTelefone() + "\n");
                buffWrite.append("Endereco: " + pair.getValue().getEndereco() + "\n");
                buffWrite.append("Email: " + pair.getValue().getEmail() + "\n \n");
                buffWrite.append("------------------------------------------" + "\n \n");
            }
            buffWrite.close();
            throw new ContatoInexistenteException();
        } catch (ContatoInexistenteException exception) {
            System.out.println("O arquivo não foi encontrado!");
            System.exit(1);
        } catch (Exception exception) {
            System.out.println("Ocorreu um erro!");
            System.exit(1);
        }
    }
}
