package visao;

import negocio.Agenda;
import negocio.Contato;

public class Agendapersis{
    public static void main(String[] args) throws Exception {
        Agenda agenda = new Agenda();

        Contato contato1 = new Contato("jorgin", "(31)99977-6655", "senegão", "jorginERREDE@gmail.com");
        Contato contato2 = new Contato("smuel", "(31)99922-1155", "senegdo", "smuelRREDE@gmail.com");
        Contato contato3 = new Contato("cabo-loso", "(31)91277-6635", "seneguo", "cabo-losoERREDE@gmail.com");

        agenda.incluirContato(contato1);
        agenda.incluirContato(contato2);
        agenda.incluirContato(contato3);

        agenda.persistirAgenda();
        agenda.lerAgenda();
    }
}
