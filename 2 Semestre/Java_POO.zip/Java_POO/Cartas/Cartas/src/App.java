import classes.Carta;


public class App {
    public static void main(String[] args) throws Exception {
     
        Carta fCard = new Carta(4, "paus");
        Carta sCard = new Carta(7, "diferentes");
    
        if(fCard.compararValores(sCard) == 1){
            System.out.println("primeira maior e naipes iguais");
        }
        
        if(fCard.compararValores(sCard) == 0){
            System.out.println("iguais");
        }
        
        if(fCard.compararValores(sCard) == -1){
            System.out.println("segunda maior");
        }
        System.out.println(fCard.compararNaipes(sCard) ? "Naipes iguais" : "Naipes Diferentes");

        //System.out.println(sete.compararValores(zap));
        
       // System.out.println(sete.compararNaipes(zap));
    
    
    
    
    }
}
