package classes;

public class Carta {
    private int valor;
    private String naipe;

    // getters and setters
    public int getValor() {
        return this.valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getNaipe() {
        return this.naipe;
    }

    public void setNaipe(String naipe) {
        this.naipe = naipe;
    }
 
    // constructers
    public Carta(int valor, String naipe) {
        this.valor = valor;
        this.naipe = naipe;
    }
    
    //metods
   public int compararValores(Carta carta){
    if(carta.getValor() < this.valor){
        return 1;
    }
    if(carta.getValor() > this.valor){
        return -1;
    }    
     return 0;   
    
   }
 
   public boolean compararNaipes(Carta carta) {
   if(carta.getNaipe().equals(this.naipe)){
     return true; 
    }
   else {
    return false;
    }

   }

    
}
