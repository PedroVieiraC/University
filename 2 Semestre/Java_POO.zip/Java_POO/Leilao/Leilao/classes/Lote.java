package PC2.aula3.classes;

import java.util.ArrayList;

public class Lote {

    private ArrayList<Produto> produtos = new ArrayList<Produto>() ;

    public ArrayList<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(ArrayList<Produto> produtos) {
        this.produtos = produtos;
    }
    
    public void inserirProduto(Produto produtos) {
        this.produtos.add(produtos);     
    }    

}
